package com.example.demo.util

import androidx.compose.ui.graphics.Color

object AppColors {
    val textColorBlue = Color(0xFF0D7590)  // #0052B4
}