import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    kotlin("jvm")
    id("org.jetbrains.compose")
    id("org.jetbrains.kotlin.plugin.compose")
    kotlin("plugin.serialization") version "1.8.20"
}

group = "com.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
    maven("https://maven.pkg.jetbrains.space/public/p/compose/dev")
    google()
}

dependencies {
    // Note, if you develop a library, you should use compose.desktop.common.
    // compose.desktop.currentOs should be used in launcher-sourceSet
    // (in a separate module for demo project and in testMain).
    // With compose.desktop.common you will also lose @Preview functionality
    implementation(compose.desktop.currentOs)
    implementation("com.github.sarxos:webcam-capture:0.3.12")
    implementation("io.ktor:ktor-client-content-negotiation:2.3.11")
    implementation("io.ktor:ktor-serialization-kotlinx-json:2.3.11")
    //implementation("io.ktor:ktor-client-core-jvm:2.3.11")
    implementation("io.ktor:ktor-client-cio-jvm:2.3.11")
    implementation("com.google.code.gson:gson:2.8.9")
}

compose.desktop {
    application {
        mainClass = "MainKt"

        nativeDistributions {
            targetFormats(TargetFormat.Dmg, TargetFormat.Msi, TargetFormat.Deb)
            packageName = "demo2"
            packageVersion = "1.0.0"
            windows {
                // Windowsga tegishli sozlamalar
                menuGroup = "Demo"
                upgradeUuid = "123e4567-e89b-12d3-a456-426614174000"  // Unique UUID
                shortcut = true  // Ishga tushirish uchun shortcut yaratish
                menu = true
                iconFile.set(project.file("resources/icon.ico"))
            }
        }
        buildTypes.release.proguard {
            optimize.set(false)
        }
    }
}
