package utils

import java.util.*

object ResourceLoader {
    private var currentLocale: Locale = Locale("en")
    private lateinit var bundle: ResourceBundle

    init {
        loadBundle()
    }

    fun setLocale(locale: Locale) {
        currentLocale = locale
        loadBundle()
    }

    private fun loadBundle() {
        bundle = ResourceBundle.getBundle("strings", currentLocale)
    }

    fun getString(key: String): String {
        return bundle.getString(key)
    }
    //key:d9b9f98bb2d0412a85e9854a4193b46d
}
