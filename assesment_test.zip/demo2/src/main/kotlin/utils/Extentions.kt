package utils

import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import androidx.compose.ui.input.pointer.PointerIcon
import org.jetbrains.skia.Image
import java.awt.Cursor
import java.awt.Desktop
import java.awt.image.BufferedImage
import java.net.URI
import java.net.URL

fun BufferedImage.resize(newWidth: Int, newHeight: Int): BufferedImage {
    val newImage = BufferedImage(newWidth, newHeight, BufferedImage.TYPE_INT_ARGB)
    val g = newImage.createGraphics()
    g.drawImage(this, 0, 0, newWidth, newHeight, null)
    g.dispose()
    return newImage
}

fun handCursor()= PointerIcon(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR))

fun openURL(url:URI){
    val desctop = Desktop.getDesktop()
    desctop.browse(url)
}
fun loadPicture(url:String): ImageBitmap {
   return Image.makeFromEncoded(URL(url).readBytes())
        .toComposeImageBitmap()
}