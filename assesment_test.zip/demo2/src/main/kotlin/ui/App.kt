package ui

import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.runtime.Composable
import ui.screen.CameraScreen
import ui.screen.HomeScreen
import ui.screen.LanguageScreen

@Composable
@Preview
fun App() {
    MaterialTheme {
       Surface {
           LanguageScreen()
       }
    }
}