package ui.screen

import androidx.compose.foundation.layout.Row
import androidx.compose.runtime.Composable
import androidx.compose.runtime.*
import data.NewsApiClient
import data.model.Article
import io.ktor.client.plugins.*
import kotlinx.coroutines.launch

@Composable
fun HomeScreen() {
    var article by remember { mutableStateOf(emptyList<Article>()) }
    var headlineTitle by remember { mutableStateOf("") }
    var searchedText by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    LaunchedEffect(searchedText){
        scope.launch {
            try {
                val newsData = if(searchedText.isNotEmpty()){
                    NewsApiClient.searchHeadlines(searchedText)
                }else{
                    NewsApiClient.getHeadlines()
                }
                article = newsData.articles
            }catch (e:ClientRequestException){
                println("Error featching data ")
            }
        }
    }
    Row {
        SidePanel( onMenuSelected = {
            headlineTitle = it
            searchedText = ""
            article = emptyList()
        },
            onNewSearched = { _searchedText,_header->
                searchedText =_searchedText
                headlineTitle =_header
                article = emptyList()
        })
        MainComponent(headlineTitle,article)
    }
}