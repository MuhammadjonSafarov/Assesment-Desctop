package ui.screen

import com.github.sarxos.webcam.Webcam
import androidx.compose.foundation.Image
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.toComposeImageBitmap
import kotlinx.coroutines.delay

@Composable
fun CameraScreen() {
    var bitmap by remember { mutableStateOf<ImageBitmap?>(null) }
    val webcam = Webcam.getDefault()
     DisposableEffect(Unit) {
        webcam.open()
        onDispose {
            webcam.close()
        }
    }

    LaunchedEffect(Unit) {
        while (true) {
            val image = webcam.image
            bitmap = image.toComposeImageBitmap()
            delay(100)
        }
    }
    bitmap?.let {
        Image(bitmap = it , contentDescription = "Camera Feed", modifier = Modifier.fillMaxSize())
    }
}
