package ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.material.Button
import androidx.compose.material.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import utils.ResourceLoader
import java.util.*

@Composable
fun LanguageScreen() {
    var currentLanguage by remember { mutableStateOf(Locale.ENGLISH) }
    var text by remember { mutableStateOf("") }
    var text1 by remember { mutableStateOf("") }
    text = ResourceLoader.getString("farewell")
    text1 = ResourceLoader.getString("greeting")
    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = text1)
        Row {
            Button(onClick = {
                currentLanguage = Locale.ENGLISH
                ResourceLoader.setLocale(currentLanguage)
                text = ResourceLoader.getString("farewell")
                text1 = ResourceLoader.getString("greeting")
            }) {
                Text("English")
            }

            Spacer(modifier = Modifier.width(8.dp))

            Button(onClick = {
                currentLanguage = Locale("uz") // O'zbekcha
                ResourceLoader.setLocale(currentLanguage)
                text = ResourceLoader.getString("farewell")
                text1 = ResourceLoader.getString("greeting")
            }) {
                Text("O'zbekcha")
            }
        }
        Text(text = text)
    }
}
