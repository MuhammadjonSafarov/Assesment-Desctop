package common

object Constant {
   val API_KEY="d9b9f98bb2d0412a85e9854a4193b46d"
}