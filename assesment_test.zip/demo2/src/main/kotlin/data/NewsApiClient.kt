package data

import common.Constant
import data.model.News
import io.ktor.client.*
import io.ktor.client.call.*
import io.ktor.client.engine.cio.*
import io.ktor.client.plugins.contentnegotiation.*
import io.ktor.client.request.*
import io.ktor.serialization.kotlinx.json.*

object NewsApiClient {
    private val client = HttpClient(CIO) {
        install(ContentNegotiation) {
            json()
        }
    }

    suspend fun getHeadlines(): News {
        val url = "https://newsapi.org/v2/top-headlines?country=us&apiKey=${Constant.API_KEY}"
        return client.get(url).body()
    }

    suspend fun searchHeadlines(query:String): News {
        val url = "https://newsapi.org/v2/everything?q=${query}&apiKey=${Constant.API_KEY}"
        return client.get(url).body()
    }
}